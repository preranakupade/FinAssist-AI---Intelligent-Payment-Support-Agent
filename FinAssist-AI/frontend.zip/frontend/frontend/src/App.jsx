
import React, { useState, useEffect, useRef } from "react";
import Markdown from "react-markdown";

import Login from "./Login";
import Signup from "./Signup";

import {
  Send,
  Bot,
  User,
  ShieldCheck,
  CheckCircle2,
  Ticket,
  Copy,
  Check,
  RotateCcw,
  Sparkles,
  ChevronRight,
  Database,
  FileText,
  Activity,
  Layers,
  Zap,
} from "lucide-react";

import "./App.css";


// =========================================================
// CONFIGURATION
// =========================================================

const API_BASE = "http://127.0.0.1:8000";

const REQUEST_TIMEOUT_MS = 60000;


// =========================================================
// SAMPLE TRANSACTIONS
// =========================================================

const SAMPLE_TRANSACTIONS = [
  {
    id: "TXN1001",
    status: "SUCCESS",
    amount: "₹5,000",
    desc: "ABC Store (UPI)",
  },
  {
    id: "TXN1002",
    status: "FAILED",
    amount: "₹2,500",
    desc: "XYZ Store (UPI)",
  },
  {
    id: "TXN1003",
    status: "PENDING",
    amount: "₹1,200",
    desc: "Online Mart (Card)",
  },
  {
    id: "TXN1004",
    status: "FAILED",
    amount: "₹7,500",
    desc: "Travel Portal (Card)",
  },
];


// =========================================================
// QUICK PROMPTS
// =========================================================

const SUGGESTIONS = [
  "Check refund eligibility for TXN1002",
  "What is the failed payment & refund policy?",
  "Create a support ticket for transaction TXN1002",
  "What is the status of transaction TXN1001?",
];


// =========================================================
// MAIN APP
// =========================================================

export default function App() {

  // =======================================================
  // AUTHENTICATION STATE
  // =======================================================

  const [authMode, setAuthMode] = useState("login");

  const [currentUser, setCurrentUser] = useState(() => {

    const savedUser = localStorage.getItem("finassist_user");
    const savedToken = localStorage.getItem("finassist_token");

    if (!savedUser || !savedToken) {
      return null;
    }

    try {
      return JSON.parse(savedUser);
    } catch {

      localStorage.removeItem("finassist_user");
      localStorage.removeItem("finassist_token");

      return null;
    }
  });


  // =======================================================
  // CHAT STATE
  // =======================================================

  const [inputMessage, setInputMessage] = useState("");
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);
  const [currentStage, setCurrentStage] = useState("");
  const [agentInfo, setAgentInfo] = useState(null);
  const [activeTab, setActiveTab] = useState("chat");
  const [copiedId, setCopiedId] = useState(null);
  const [backendStatus, setBackendStatus] = useState("checking");


  // =======================================================
  // REFS
  // =======================================================

  const messagesEndRef = useRef(null);
  const textareaRef = useRef(null);

  const streamAccumulatorRef = useRef("");

  const metadataRef = useRef({
    sources: [],
    tools_used: [],
    ticket_id: null,
  });


  // =======================================================
  // CHECK LOGIN SESSION
  // =======================================================

  useEffect(() => {

    const token = localStorage.getItem("finassist_token");
    const savedUser = localStorage.getItem("finassist_user");

    if (!token || !savedUser) {

      setCurrentUser(null);

      return;
    }

    try {

      const user = JSON.parse(savedUser);

      setCurrentUser(user);

    } catch {

      localStorage.removeItem("finassist_token");
      localStorage.removeItem("finassist_user");

      setCurrentUser(null);
    }

  }, []);


  // =======================================================
  // LOGIN SUCCESS
  // =======================================================

  const handleLogin = (user) => {

    /*
      Login.jsx should store:

      finassist_token
      finassist_user

      Then it calls:

      onLogin(user)

      Setting currentUser automatically switches
      the application from Login page to Main page.
    */

    setCurrentUser(user);

    setMessages([]);
    setAgentInfo(null);
    setCurrentStage("");

  };


  // =======================================================
  // SIGNUP SUCCESS
  // =======================================================

  const handleSignup = () => {

    /*
      After successful registration,
      show the Login page.

      User must sign in using the newly
      created account.
    */

    setAuthMode("login");
  };


  // =======================================================
  // LOGOUT
  // =======================================================

  const handleLogout = () => {

    // Remove authentication data

    localStorage.removeItem("finassist_token");
    localStorage.removeItem("finassist_user");


    // Clear application state

    setCurrentUser(null);

    setMessages([]);
    setAgentInfo(null);
    setCurrentStage("");
    setInputMessage("");
    setActiveTab("chat");


    // Automatically show Login page

    setAuthMode("login");
  };


  // =======================================================
  // BACKEND HEALTH CHECK
  // =======================================================

  useEffect(() => {

    // Don't continuously check backend
    // while user is on authentication screen.

    if (!currentUser) {
      return;
    }

    async function checkHealth() {

      try {

        const res = await fetch(
          `${API_BASE}/health`,
          {
            method: "GET",
          }
        );

        if (res.ok) {

          setBackendStatus("online");

        } else {

          setBackendStatus("offline");

        }

      } catch {

        setBackendStatus("offline");

      }
    }


    checkHealth();

    const interval = setInterval(
      checkHealth,
      15000
    );


    return () => clearInterval(interval);

  }, [currentUser]);


  // =======================================================
  // AUTO SCROLL
  // =======================================================

  useEffect(() => {

    messagesEndRef.current?.scrollIntoView({
      behavior: "smooth",
    });

  }, [messages, currentStage]);


  // =======================================================
  // TEXTAREA AUTO RESIZE
  // =======================================================

  const handleTextareaChange = (e) => {

    setInputMessage(e.target.value);

    if (textareaRef.current) {

      textareaRef.current.style.height = "auto";

      textareaRef.current.style.height =
        `${Math.min(
          textareaRef.current.scrollHeight,
          140
        )}px`;
    }
  };


  // =======================================================
  // COPY
  // =======================================================

  const handleCopy = async (text, id) => {

    try {

      await navigator.clipboard.writeText(text);

      setCopiedId(id);

      setTimeout(() => {
        setCopiedId(null);
      }, 2000);

    } catch (error) {

      console.error(
        "Copy failed:",
        error
      );
    }
  };


  // =======================================================
  // CLEAR CHAT
  // =======================================================

  const clearChat = () => {

    if (
      window.confirm(
        "Are you sure you want to clear the conversation?"
      )
    ) {

      setMessages([]);

      setAgentInfo(null);

      setCurrentStage("");
    }
  };


  // =======================================================
  // SUBMIT QUERY
  // =======================================================

  const submitQuery = async (queryText) => {

    const textToSend =
      (queryText || inputMessage).trim();


    if (!textToSend || loading) {
      return;
    }


    // =====================================================
    // USER MESSAGE
    // =====================================================

    const userTimestamp =
      new Date().toLocaleTimeString(
        [],
        {
          hour: "2-digit",
          minute: "2-digit",
        }
      );


    const newMessages = [

      ...messages,

      {
        role: "user",
        content: textToSend,
        timestamp: userTimestamp,
      },

    ];


    setMessages(newMessages);

    setInputMessage("");


    if (textareaRef.current) {

      textareaRef.current.style.height =
        "auto";
    }


    setLoading(true);

    setCurrentStage(
      "Connecting to FinAssist AI..."
    );


    // =====================================================
    // ASSISTANT PLACEHOLDER
    // =====================================================

    const assistantIndex =
      newMessages.length;


    const assistantPlaceholder = {

      role: "assistant",

      content: "",

      timestamp:
        new Date().toLocaleTimeString(
          [],
          {
            hour: "2-digit",
            minute: "2-digit",
          }
        ),

      isStreaming: true,

      sources: [],

      tools_used: [],

      ticket_id: null,
    };


    setMessages([
      ...newMessages,
      assistantPlaceholder,
    ]);


    // =====================================================
    // STREAM REQUEST
    // =====================================================

    const controller =
      new AbortController();


    const timeoutId =
      setTimeout(
        () => controller.abort(),
        REQUEST_TIMEOUT_MS
      );


    try {

      const response =
        await fetch(
          `${API_BASE}/api/chat/stream`,
          {
            method: "POST",

            headers: {
              "Content-Type":
                "application/json",
            },

            body: JSON.stringify({
              message: textToSend,
            }),

            signal: controller.signal,
          }
        );


      if (
        !response.ok ||
        !response.body
      ) {

        throw new Error(
          "Streaming unavailable"
        );
      }


      const reader =
        response.body.getReader();


      const decoder =
        new TextDecoder("utf-8");


      let buffer = "";


      streamAccumulatorRef.current = "";


      metadataRef.current = {
        sources: [],
        tools_used: [],
        ticket_id: null,
      };


      // ===================================================
      // READ STREAM
      // ===================================================

      while (true) {

        const {
          done,
          value,
        } = await reader.read();


        if (done) {
          break;
        }


        buffer += decoder.decode(
          value,
          {
            stream: true,
          }
        );


        const lines =
          buffer.split("\n");


        buffer =
          lines.pop() || "";


        for (const line of lines) {

          const trimmed =
            line.trim();


          if (
            !trimmed.startsWith(
              "data: "
            )
          ) {
            continue;
          }


          const jsonStr =
            trimmed.slice(6);


          if (!jsonStr) {
            continue;
          }


          try {

            const event =
              JSON.parse(
                jsonStr
              );


            // STATUS

            if (
              event.type ===
              "status"
            ) {

              setCurrentStage(
                event.message
              );
            }


            // TOKEN

            else if (
              event.type ===
              "token"
            ) {

              streamAccumulatorRef.current +=
                event.content;


              const newText =
                streamAccumulatorRef.current;


              setMessages(
                (prev) => {

                  const updated =
                    [...prev];


                  if (
                    updated[
                      assistantIndex
                    ]
                  ) {

                    updated[
                      assistantIndex
                    ] = {

                      ...updated[
                        assistantIndex
                      ],

                      content:
                        newText,
                    };
                  }


                  return updated;
                }
              );
            }


            // TOOL

            else if (
              event.type ===
              "tool_executed"
            ) {

              if (
                event.tool &&
                !metadataRef.current.tools_used.includes(
                  event.tool
                )
              ) {

                metadataRef.current.tools_used.push(
                  event.tool
                );
              }
            }


            // DONE

            else if (
              event.type ===
              "done"
            ) {

              metadataRef.current = {

                sources:
                  event.sources ||
                  [],

                tools_used:
                  event.tools_used ||
                  [],

                ticket_id:
                  event.ticket_id ||
                  null,
              };


              if (
                event.answer &&
                !streamAccumulatorRef.current
              ) {

                streamAccumulatorRef.current =
                  event.answer;
              }
            }

          } catch (error) {

            console.warn(
              "SSE JSON Parse Error:",
              error
            );
          }
        }
      }


      // ===================================================
      // FINAL RESPONSE
      // ===================================================

      const finalText =
        streamAccumulatorRef.current ||
        "I have processed your query.";


      const finalMeta =
        metadataRef.current;


      setMessages(
        (prev) => {

          const updated =
            [...prev];


          if (
            updated[
              assistantIndex
            ]
          ) {

            updated[
              assistantIndex
            ] = {

              ...updated[
                assistantIndex
              ],

              content:
                finalText,

              isStreaming:
                false,

              sources:
                finalMeta.sources,

              tools_used:
                finalMeta.tools_used,

              ticket_id:
                finalMeta.ticket_id,
            };
          }


          return updated;
        }
      );


      setAgentInfo({

        tools_used:
          finalMeta.tools_used,

        sources:
          finalMeta.sources,

        ticket_id:
          finalMeta.ticket_id,

        answer:
          finalText,
      });


    } catch (streamError) {

      console.warn(
        "Streaming failed. Trying normal API...",
        streamError
      );


      setCurrentStage(
        "Processing request..."
      );


      // =================================================
      // FALLBACK API
      // =================================================

      const fallbackController =
        new AbortController();


      const fallbackTimeoutId =
        setTimeout(
          () =>
            fallbackController.abort(),
          REQUEST_TIMEOUT_MS
        );


      try {

        const syncResponse =
          await fetch(
            `${API_BASE}/api/chat`,
            {
              method: "POST",

              headers: {
                "Content-Type":
                  "application/json",
              },

              body: JSON.stringify({
                message:
                  textToSend,
              }),

              signal:
                fallbackController.signal,
            }
          );


        clearTimeout(
          fallbackTimeoutId
        );


        if (!syncResponse.ok) {

          throw new Error(
            "Backend request failed"
          );
        }


        const data =
          await syncResponse.json();


        setMessages(
          (prev) => {

            const updated =
              [...prev];


            if (
              updated[
                assistantIndex
              ]
            ) {

              updated[
                assistantIndex
              ] = {

                role:
                  "assistant",

                content:
                  data.answer,

                isStreaming:
                  false,

                sources:
                  data.sources ||
                  [],

                tools_used:
                  data.tools_used ||
                  [],

                ticket_id:
                  data.ticket_id ||
                  null,

                timestamp:
                  new Date().toLocaleTimeString(
                    [],
                    {
                      hour:
                        "2-digit",

                      minute:
                        "2-digit",
                    }
                  ),
              };
            }


            return updated;
          }
        );


        setAgentInfo(data);


      } catch (error) {

        clearTimeout(
          fallbackTimeoutId
        );


        console.error(error);


        const timedOut =
          error?.name ===
          "AbortError";


        setMessages(
          (prev) => {

            const updated =
              [...prev];


            if (
              updated[
                assistantIndex
              ]
            ) {

              updated[
                assistantIndex
              ] = {

                role:
                  "assistant",

                content:
                  timedOut

                    ? "⚠️ The request timed out. The model may still be loading — please try again in a moment."

                    : "⚠️ Unable to connect to FinAssist AI service. Please make sure the backend server is running on port 8000.",

                isStreaming:
                  false,

                sources:
                  [],

                tools_used:
                  [],

                ticket_id:
                  null,

                timestamp:
                  new Date().toLocaleTimeString(
                    [],
                    {
                      hour:
                        "2-digit",

                      minute:
                        "2-digit",
                    }
                  ),
              };
            }


            return updated;
          }
        );
      }

    } finally {

      clearTimeout(
        timeoutId
      );

      setLoading(false);

      setCurrentStage("");
    }
  };


  // =======================================================
  // ENTER KEY
  // =======================================================

  const handleKeyDown = (event) => {

    if (
      event.key === "Enter" &&
      !event.shiftKey
    ) {

      event.preventDefault();

      submitQuery();
    }
  };


  // =======================================================
  // AUTHENTICATION SCREEN
  // =======================================================

  /*
    IMPORTANT:

    This check happens AFTER all hooks.

    Therefore React's Rules of Hooks are not violated.
  */

  if (!currentUser) {

    if (authMode === "signup") {

      return (
        <Signup

          onSignup={
            handleSignup
          }

          onSwitchToLogin={() =>
            setAuthMode("login")
          }

        />
      );
    }


    return (
      <Login

        onLogin={
          handleLogin
        }

        onSwitchToSignup={() =>
          setAuthMode("signup")
        }

      />
    );
  }


  // =======================================================
  // MAIN FINASSIST PAGE
  // =======================================================

  return (

    <div className="finassist-app">

      {/* =================================================
          HEADER
      ================================================= */}

      <header className="fin-header">

        <div className="header-brand">

          <div className="brand-logo-container">

            <ShieldCheck
              className="brand-icon"
              size={24}
            />

            <div className="brand-glow"></div>

          </div>


          <div>

            <div className="brand-title-row">

              <h1 className="brand-title">
                FinAssist AI
              </h1>

              <span className="badge-fintech">
                Payment Support Agent
              </span>

            </div>


            <p className="brand-subtitle">
              Automated resolutions,
              transaction investigations
              & policy RAG
            </p>

          </div>

        </div>


        <div className="header-actions">

          {/* MOBILE TABS */}

          <div className="mobile-view-tabs">

            <button
              className={`view-tab-btn ${
                activeTab === "chat"
                  ? "active"
                  : ""
              }`}
              onClick={() =>
                setActiveTab("chat")
              }
            >

              <Bot size={16} />

              <span>
                Chat
              </span>

            </button>


            <button
              className={`view-tab-btn ${
                activeTab === "activity"
                  ? "active"
                  : ""
              }`}
              onClick={() =>
                setActiveTab("activity")
              }
            >

              <Activity size={16} />

              <span>
                Activity
              </span>

              {agentInfo && (
                <span className="tab-dot"></span>
              )}

            </button>

          </div>


          <div className="header-right-tools">

            {/* LOGGED IN USER */}

            <div className="logged-user">

              <div className="logged-user-avatar">

                {currentUser?.name
                  ?.charAt(0)
                  .toUpperCase()}

              </div>


              <div className="logged-user-info">

                <strong>
                  {currentUser?.name}
                </strong>

                <span>
                  {currentUser?.email}
                </span>

              </div>

            </div>


            {/* BACKEND STATUS */}

            <div className="status-indicator">

              <span
                className={`status-pulse ${
                  backendStatus ===
                  "online"
                    ? "online"
                    : "offline"
                }`}
              ></span>


              <span className="status-label">

                {backendStatus ===
                "online"

                  ? "AI Online"

                  : "Connecting..."}

              </span>

            </div>


            {/* RESET */}

            {messages.length > 0 && (

              <button
                className="btn-secondary"
                onClick={clearChat}
                title="Reset conversation"
              >

                <RotateCcw
                  size={15}
                />

                <span className="desktop-only">
                  Reset
                </span>

              </button>

            )}


            {/* LOGOUT */}

            <button
              className="btn-secondary"
              onClick={handleLogout}
              title="Sign out"
            >

              <ShieldCheck
                size={15}
              />

              <span className="desktop-only">
                Sign Out
              </span>

            </button>

          </div>

        </div>

      </header>


      {/* =================================================
          MAIN WORKSPACE
      ================================================= */}

      <main className="fin-workspace">


        {/* =================================================
            CHAT
        ================================================= */}

        <section
          className={`chat-viewport ${
            activeTab === "chat"
              ? "active"
              : "hidden-on-mobile"
          }`}
        >

          {/* MESSAGES */}

          <div className="messages-scroll">

            {messages.length === 0 ? (

              <div className="welcome-hero">

                <div className="hero-icon-bubble">

                  <Sparkles
                    size={32}
                    className="sparkle-icon"
                  />

                </div>


                <h2>
                  How can FinAssist assist you today?
                </h2>


                <p className="hero-description">

                  FinAssist AI uses local RAG
                  and automated database agents
                  to resolve payment disputes,
                  investigate failed transactions,
                  verify refund eligibility,
                  and raise priority support tickets.

                </p>


                {/* QUICK PROMPTS */}

                <div className="quick-prompts-container">

                  <div className="quick-prompts-label">
                    Try asking:
                  </div>


                  <div className="quick-prompt-chips">

                    {SUGGESTIONS.map(
                      (suggestion, idx) => (

                        <button
                          key={idx}
                          className="prompt-chip"
                          onClick={() =>
                            submitQuery(
                              suggestion
                            )
                          }
                        >

                          <ChevronRight
                            size={14}
                            className="chip-arrow"
                          />

                          <span>
                            {suggestion}
                          </span>

                        </button>

                      )
                    )}

                  </div>

                </div>

              </div>

            ) : (

              <div className="messages-stream">

                {messages.map(
                  (item, index) => (

                    <div
                      key={index}
                      className={`message-row ${
                        item.role === "user"
                          ? "user-row"
                          : "assistant-row"
                      }`}
                    >

                      <div className="message-avatar">

                        {item.role === "user"

                          ? <User size={17} />

                          : <Bot size={17} />}

                      </div>


                      <div className="message-bubble-wrapper">

                        <div className="message-meta">

                          <span className="sender-name">

                            {item.role === "user"

                              ? "You"

                              : "FinAssist AI"}

                          </span>


                          {item.timestamp && (

                            <span className="message-time">

                              {item.timestamp}

                            </span>

                          )}

                        </div>


                        <div className="message-bubble">

                          {item.role === "assistant" ? (

                            <div className="markdown-content">

                              <Markdown>
                                {item.content}
                              </Markdown>


                              {item.isStreaming && (

                                <span
                                  className="streaming-cursor"
                                  title="Generating..."
                                ></span>

                              )}

                            </div>

                          ) : (

                            <div className="user-text">
                              {item.content}
                            </div>

                          )}


                          {/* TICKET */}

                          {item.ticket_id && (

                            <div className="ticket-card">

                              <div className="ticket-header">

                                <div className="ticket-title">

                                  <Ticket
                                    size={16}
                                    className="text-emerald"
                                  />

                                  <span>
                                    Support Ticket Created
                                  </span>

                                </div>


                                <span className="badge-ticket-status">
                                  OPEN
                                </span>

                              </div>


                              <div className="ticket-body">

                                <span className="ticket-label">
                                  Ticket ID:
                                </span>


                                <code className="ticket-code">
                                  {item.ticket_id}
                                </code>


                                <button
                                  className="ticket-copy-btn"
                                  onClick={() =>
                                    handleCopy(
                                      item.ticket_id,
                                      `tkt-${index}`
                                    )
                                  }
                                >

                                  {copiedId ===
                                  `tkt-${index}`

                                    ? <Check size={14} />

                                    : <Copy size={14} />}


                                  <span>

                                    {copiedId ===
                                    `tkt-${index}`

                                      ? "Copied"

                                      : "Copy"}

                                  </span>

                                </button>

                              </div>

                            </div>

                          )}


                          {/* MESSAGE FOOTER */}

                          {item.role ===
                            "assistant" &&
                            !item.isStreaming &&
                            item.content && (

                              <div className="bubble-footer">

                                <button
                                  className="bubble-action-btn"
                                  onClick={() =>
                                    handleCopy(
                                      item.content,
                                      `msg-${index}`
                                    )
                                  }
                                >

                                  {copiedId ===
                                  `msg-${index}`

                                    ? <Check size={13} />

                                    : <Copy size={13} />}


                                  <span>

                                    {copiedId ===
                                    `msg-${index}`

                                      ? "Copied"

                                      : "Copy"}

                                  </span>

                                </button>


                                {item.tools_used &&
                                  item.tools_used.length >
                                    0 && (

                                    <div className="bubble-tools-tag">

                                      <Zap size={12} />

                                      <span>

                                        {
                                          item
                                            .tools_used
                                            .length
                                        }{" "}
                                        tools executed

                                      </span>

                                    </div>

                                  )}

                              </div>

                            )}

                        </div>

                      </div>

                    </div>

                  )
                )}


                {/* PROGRESS */}

                {loading &&
                  currentStage && (

                    <div className="agent-progress-row">

                      <div className="progress-bubble">

                        <div className="spinner-dots">

                          <span></span>
                          <span></span>
                          <span></span>

                        </div>


                        <span className="progress-text">

                          {currentStage}

                        </span>

                      </div>

                    </div>

                  )}


                <div
                  ref={messagesEndRef}
                />

              </div>

            )}

          </div>


          {/* =================================================
              INPUT
          ================================================= */}

          <div className="chat-input-wrapper">

            <div className="input-box-container">

              <textarea
                ref={textareaRef}
                value={inputMessage}
                onChange={
                  handleTextareaChange
                }
                onKeyDown={
                  handleKeyDown
                }
                placeholder="Ask about payments, failed transactions, refunds..."
                rows={1}
                disabled={loading}
              />


              <button
                className="btn-send"
                onClick={() =>
                  submitQuery()
                }
                disabled={
                  loading ||
                  !inputMessage.trim()
                }
                title="Send message (Enter)"
              >

                <Send size={18} />

              </button>

            </div>


            <div className="input-keyboard-hint">

              <span>

                Press{" "}
                <strong>
                  Enter ↵
                </strong>{" "}
                to send,{" "}
                <strong>
                  Shift + Enter
                </strong>{" "}
                for new line

              </span>

            </div>

          </div>

        </section>


        {/* =================================================
            ACTIVITY SIDEBAR
        ================================================= */}

        <aside
          className={`activity-sidebar ${
            activeTab === "activity"
              ? "active"
              : "hidden-on-mobile"
          }`}
        >

          <div className="sidebar-header">

            <div className="sidebar-title">

              <Activity
                size={18}
                className="text-indigo"
              />

              <h3>
                Agent Activity
              </h3>

            </div>


            <span className="badge-pill">
              Inspector
            </span>

          </div>


          <div className="sidebar-scrollable">


            {/* ACTIVITY */}

            {!agentInfo ? (

              <div className="empty-activity-card">

                <Bot
                  size={36}
                  className="empty-icon-pulse"
                />

                <h4>
                  Ready to Assist
                </h4>

                <p>
                  Run any query to observe
                  real-time tool calls,
                  database lookups,
                  and policy citations.
                </p>

              </div>

            ) : (

              <div className="activity-details">


                {/* TOOLS */}

                <div className="inspector-card">

                  <div className="inspector-card-header">

                    <Database size={15} />

                    <h4>
                      Tools Executed
                    </h4>

                  </div>


                  <div className="inspector-card-body">

                    {agentInfo.tools_used &&
                    agentInfo.tools_used.length >
                      0 ? (

                      <div className="tool-tags-list">

                        {agentInfo.tools_used.map(
                          (tool, idx) => (

                            <div
                              key={idx}
                              className="tool-badge-item"
                            >

                              <CheckCircle2
                                size={14}
                                className="text-emerald"
                              />

                              <code>
                                {tool}
                              </code>

                            </div>

                          )
                        )}

                      </div>

                    ) : (

                      <div className="tool-badge-item">

                        <CheckCircle2
                          size={14}
                          className="text-emerald"
                        />

                        <span>
                          Direct RAG Knowledge synthesis
                        </span>

                      </div>

                    )}

                  </div>

                </div>


                {/* KNOWLEDGE */}

                <div className="inspector-card">

                  <div className="inspector-card-header">

                    <FileText size={15} />

                    <h4>
                      Knowledge Documents
                    </h4>

                  </div>


                  <div className="inspector-card-body">

                    {agentInfo.sources &&
                    agentInfo.sources.length >
                      0 ? (

                      <ul className="source-list">

                        {agentInfo.sources.map(
                          (src, idx) => (

                            <li
                              key={idx}
                              className="source-list-item"
                            >

                              <FileText
                                size={13}
                                className="text-slate"
                              />

                              <span>
                                {src}
                              </span>

                            </li>

                          )
                        )}

                      </ul>

                    ) : (

                      <p className="no-sources-text">

                        No policy documents referenced.

                      </p>

                    )}

                  </div>

                </div>


                {/* TICKET */}

                {agentInfo.ticket_id && (

                  <div className="inspector-card ticket-highlight">

                    <div className="inspector-card-header">

                      <Ticket
                        size={15}
                        className="text-emerald"
                      />

                      <h4>
                        Generated Ticket
                      </h4>

                    </div>


                    <div className="inspector-card-body">

                      <div className="ticket-inspector-box">

                        <span className="tkt-number">

                          {agentInfo.ticket_id}

                        </span>


                        <button
                          className="tkt-inspector-copy"
                          onClick={() =>
                            handleCopy(
                              agentInfo.ticket_id,
                              "sidebar-tkt"
                            )
                          }
                        >

                          {copiedId ===
                          "sidebar-tkt"

                            ? <Check size={14} />

                            : <Copy size={14} />}

                        </button>

                      </div>


                      <div className="ticket-meta-row">

                        <span className="meta-badge-green">
                          Status: OPEN
                        </span>

                        <span className="meta-badge-amber">
                          Priority: Auto-Assigned
                        </span>

                      </div>

                    </div>

                  </div>

                )}

              </div>

            )}


            {/* TEST TRANSACTIONS */}

            <div className="inspector-card test-data-card">

              <div className="inspector-card-header">

                <Layers size={15} />

                <h4>
                  Sample Test Transactions
                </h4>

              </div>


              <div className="inspector-card-body">

                <p className="test-data-desc">

                  Click any transaction to
                  quickly test lookup:

                </p>


                <div className="sample-txn-grid">

                  {SAMPLE_TRANSACTIONS.map(
                    (txn) => (

                      <button
                        key={txn.id}
                        className="txn-card-btn"
                        onClick={() =>
                          submitQuery(
                            `Check status and details for transaction ${txn.id}`
                          )
                        }
                        title={`Click to check ${txn.id}`}
                      >

                        <div className="txn-card-top">

                          <span className="txn-id-tag">
                            {txn.id}
                          </span>


                          <span
                            className={`txn-status-badge ${txn.status.toLowerCase()}`}
                          >
                            {txn.status}
                          </span>

                        </div>


                        <div className="txn-card-desc">

                          <span>
                            {txn.desc}
                          </span>

                          <strong className="txn-amt">
                            {txn.amount}
                          </strong>

                        </div>

                      </button>

                    )
                  )}

                </div>

              </div>

            </div>

          </div>

        </aside>

      </main>

    </div>
  );
}

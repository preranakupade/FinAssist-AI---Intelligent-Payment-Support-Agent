import React, { useState } from "react";
import {
  ShieldCheck,
  Mail,
  Lock,
  ArrowRight,
  Sparkles
} from "lucide-react";
import "./Auth.css";

const API_BASE = "http://127.0.0.1:8000";

export default function Login({ onLogin, onSwitchToSignup }) {

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleLogin = async (event) => {

    event.preventDefault();

    setError("");

    if (!email || !password) {

      setError("Please enter your email and password.");

      return;
    }

    setLoading(true);

    try {

      const response = await fetch(
        `${API_BASE}/api/auth/login`,
        {
          method: "POST",

          headers: {
            "Content-Type": "application/json"
          },

          body: JSON.stringify({
            email,
            password
          })
        }
      );

      const data = await response.json();

      if (!response.ok) {

        throw new Error(
          data.detail || "Login failed."
        );
      }

      localStorage.setItem(
        "finassist_token",
        data.access_token
      );

      localStorage.setItem(
        "finassist_user",
        JSON.stringify(data.user)
      );

      onLogin(data.user);

    } catch (error) {

      setError(
        error.message ||
        "Unable to connect to FinAssist AI."
      );

    } finally {

      setLoading(false);
    }
  };

  return (
    <div className="auth-page">

      <div className="auth-background-glow"></div>

      <div className="auth-container">

        {/* LEFT BRANDING */}

        <div className="auth-brand-panel">

          <div className="auth-logo">
            <ShieldCheck size={34} />
          </div>

          <h1>
            FinAssist <span>AI</span>
          </h1>

          <p className="auth-brand-description">
            Intelligent payment support powered by
            LLM, RAG and automated transaction tools.
          </p>

          <div className="auth-feature">

            <Sparkles size={18} />

            <div>
              <strong>AI-Powered Support</strong>
              <p>
                Investigate payments, refunds and
                support requests instantly.
              </p>
            </div>

          </div>

          <div className="auth-feature">

            <ShieldCheck size={18} />

            <div>
              <strong>Secure Access</strong>
              <p>
                Your FinAssist workspace is protected
                with authenticated access.
              </p>
            </div>

          </div>

        </div>


        {/* LOGIN CARD */}

        <div className="auth-card">

          <div className="auth-card-header">

            <h2>Welcome back</h2>

            <p>
              Sign in to access your FinAssist workspace.
            </p>

          </div>


          {error && (
            <div className="auth-error">
              {error}
            </div>
          )}


          <form onSubmit={handleLogin}>

            <label>Email address</label>

            <div className="auth-input-wrapper">

              <Mail size={18} />

              <input
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) =>
                  setEmail(e.target.value)
                }
              />

            </div>


            <label>Password</label>

            <div className="auth-input-wrapper">

              <Lock size={18} />

              <input
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) =>
                  setPassword(e.target.value)
                }
              />

            </div>


            <button
              className="auth-submit-btn"
              type="submit"
              disabled={loading}
            >

              {loading
                ? "Signing in..."
                : "Sign In"
              }

              {!loading && (
                <ArrowRight size={18} />
              )}

            </button>

          </form>


          <div className="auth-switch">

            Don't have an account?

            <button onClick={onSwitchToSignup}>
              Create account
            </button>

          </div>

        </div>

      </div>

    </div>
  );
}
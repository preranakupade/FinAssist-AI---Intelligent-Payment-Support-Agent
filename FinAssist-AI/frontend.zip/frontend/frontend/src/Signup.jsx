import React, { useState } from "react";
import {
  ShieldCheck,
  Mail,
  Lock,
  User,
  ArrowRight,
  CheckCircle2
} from "lucide-react";

import "./Auth.css";

const API_BASE = "http://127.0.0.1:8000";

export default function Signup({ onSignup, onSwitchToLogin }) {

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSignup = async (event) => {

    event.preventDefault();

    setError("");

    if (!name || !email || !password || !confirmPassword) {

      setError("Please fill in all fields.");

      return;
    }

    if (password.length < 6) {

      setError(
        "Password must contain at least 6 characters."
      );

      return;
    }

    if (password !== confirmPassword) {

      setError("Passwords do not match.");

      return;
    }

    setLoading(true);

    try {

      const response = await fetch(
        `${API_BASE}/api/auth/signup`,
        {
          method: "POST",

          headers: {
            "Content-Type": "application/json"
          },

          body: JSON.stringify({
            name,
            email,
            password
          })
        }
      );

      const data = await response.json();

      if (!response.ok) {

        throw new Error(
          data.detail || "Signup failed."
        );
      }

      onSignup();

    } catch (error) {

      setError(
        error.message ||
        "Unable to create account."
      );

    } finally {

      setLoading(false);
    }
  };

  return (
    <div className="auth-page">

      <div className="auth-background-glow"></div>

      <div className="auth-container">

        {/* BRAND */}

        <div className="auth-brand-panel">

          <div className="auth-logo">
            <ShieldCheck size={34} />
          </div>

          <h1>
            Join FinAssist <span>AI</span>
          </h1>

          <p className="auth-brand-description">
            Create your secure workspace and
            experience intelligent payment support.
          </p>

          <div className="signup-benefits">

            <div>
              <CheckCircle2 size={17} />
              AI-powered payment investigation
            </div>

            <div>
              <CheckCircle2 size={17} />
              Transaction database lookup
            </div>

            <div>
              <CheckCircle2 size={17} />
              Policy-based RAG responses
            </div>

            <div>
              <CheckCircle2 size={17} />
              Automated support tickets
            </div>

          </div>

        </div>


        {/* SIGNUP */}

        <div className="auth-card">

          <div className="auth-card-header">

            <h2>Create account</h2>

            <p>
              Set up your FinAssist AI account.
            </p>

          </div>


          {error && (
            <div className="auth-error">
              {error}
            </div>
          )}


          <form onSubmit={handleSignup}>

            <label>Full name</label>

            <div className="auth-input-wrapper">

              <User size={18} />

              <input
                type="text"
                placeholder="Your name"
                value={name}
                onChange={(e) =>
                  setName(e.target.value)
                }
              />

            </div>


            <label>Email address</label>

            <div className="auth-input-wrapper">

              <Mail size={18} />

              <input
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) =>
                  setEmail(e.target.value)
                }
              />

            </div>


            <label>Password</label>

            <div className="auth-input-wrapper">

              <Lock size={18} />

              <input
                type="password"
                placeholder="Minimum 6 characters"
                value={password}
                onChange={(e) =>
                  setPassword(e.target.value)
                }
              />

            </div>


            <label>Confirm password</label>

            <div className="auth-input-wrapper">

              <Lock size={18} />

              <input
                type="password"
                placeholder="Confirm password"
                value={confirmPassword}
                onChange={(e) =>
                  setConfirmPassword(e.target.value)
                }
              />

            </div>


            <button
              className="auth-submit-btn"
              type="submit"
              disabled={loading}
            >

              {loading
                ? "Creating account..."
                : "Create Account"
              }

              {!loading && (
                <ArrowRight size={18} />
              )}

            </button>

          </form>


          <div className="auth-switch">

            Already have an account?

            <button onClick={onSwitchToLogin}>
              Sign in
            </button>

          </div>

        </div>

      </div>

    </div>
  );
}
from datetime import datetime, timezone

from fastapi import FastAPI, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, EmailStr

from database import (
    get_connection,
    initialize_database,
    initialize_auth_database,
)

from models import ChatRequest, ChatResponse

from agent import run_agent, stream_agent

from auth import (
    hash_password,
    verify_password,
    create_access_token,
    verify_token,
)


# =========================================================
# FASTAPI APPLICATION
# =========================================================

app = FastAPI(
    title="FinAssist AI API",
    description="LLM + RAG + AI Agent for payment support",
    version="1.0.0",
)


# =========================================================
# CORS CONFIGURATION
# =========================================================

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:3000",
        "http://127.0.0.1:3000",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# =========================================================
# DATABASE INITIALIZATION
# =========================================================

@app.on_event("startup")
def startup():
    """
    Initialize application databases when FastAPI starts.
    """
    initialize_database()
    initialize_auth_database()


# =========================================================
# ROOT ENDPOINT
# =========================================================

@app.get("/")
def root():
    return {
        "message": "FinAssist AI Backend is running",
        "version": "1.0.0",
    }


# =========================================================
# HEALTH CHECK
# =========================================================

@app.get("/health")
def health():
    return {
        "status": "healthy",
        "service": "FinAssist AI",
    }


# =========================================================
# AUTHENTICATION MODELS
# =========================================================

class SignupRequest(BaseModel):
    name: str
    email: EmailStr
    password: str


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


# =========================================================
# SIGN UP
# =========================================================

@app.post("/api/auth/signup")
def signup(request: SignupRequest):

    name = request.name.strip()
    email = request.email.lower().strip()
    password = request.password

    # Validate name
    if len(name) < 2:
        raise HTTPException(
            status_code=400,
            detail="Please enter a valid name.",
        )

    # Validate password
    if len(password) < 6:
        raise HTTPException(
            status_code=400,
            detail="Password must contain at least 6 characters.",
        )

    connection = get_connection()
    cursor = connection.cursor()

    try:

        # Check whether user already exists
        cursor.execute(
            """
            SELECT id
            FROM users
            WHERE email = ?
            """,
            (email,),
        )

        existing_user = cursor.fetchone()

        if existing_user:
            raise HTTPException(
                status_code=409,
                detail="An account with this email already exists.",
            )

        # Hash password
        password_hash = hash_password(password)

        # Current UTC time
        created_at = datetime.now(
            timezone.utc
        ).isoformat()

        # Insert user
        cursor.execute(
            """
            INSERT INTO users
            (
                name,
                email,
                password_hash,
                created_at
            )
            VALUES (?, ?, ?, ?)
            """,
            (
                name,
                email,
                password_hash,
                created_at,
            ),
        )

        connection.commit()

        return {
            "success": True,
            "message": "Account created successfully.",
        }

    finally:
        connection.close()


# =========================================================
# LOGIN
# =========================================================

@app.post("/api/auth/login")
def login(request: LoginRequest):

    email = request.email.lower().strip()

    connection = get_connection()
    cursor = connection.cursor()

    try:

        cursor.execute(
            """
            SELECT *
            FROM users
            WHERE email = ?
            """,
            (email,),
        )

        user = cursor.fetchone()

    finally:
        connection.close()

    # User doesn't exist
    if not user:
        raise HTTPException(
            status_code=401,
            detail="Invalid email or password.",
        )

    # Verify password
    if not verify_password(
        request.password,
        user["password_hash"],
    ):
        raise HTTPException(
            status_code=401,
            detail="Invalid email or password.",
        )

    # Create JWT token
    token = create_access_token(
        {
            "sub": str(user["id"]),
            "email": user["email"],
            "name": user["name"],
        }
    )

    return {
        "success": True,
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "id": user["id"],
            "name": user["name"],
            "email": user["email"],
        },
    }


# =========================================================
# GET CURRENT USER
# =========================================================

@app.get("/api/auth/me")
def get_current_user(
    authorization: str | None = Header(default=None),
):

    # Authorization header missing
    if not authorization:
        raise HTTPException(
            status_code=401,
            detail="Authentication required.",
        )

    # Invalid authorization format
    if not authorization.startswith("Bearer "):
        raise HTTPException(
            status_code=401,
            detail="Invalid authentication header.",
        )

    # Extract token
    token = authorization.split(
        " ",
        1,
    )[1]

    # Verify JWT
    payload = verify_token(token)

    if not payload:
        raise HTTPException(
            status_code=401,
            detail="Invalid or expired token.",
        )

    return {
        "authenticated": True,
        "user": {
            "id": payload.get("sub"),
            "email": payload.get("email"),
            "name": payload.get("name"),
        },
    }


# =========================================================
# CHAT ENDPOINT
# =========================================================

@app.post(
    "/api/chat",
    response_model=ChatResponse,
)
def chat(request: ChatRequest):
    """
    Synchronous AI agent endpoint.
    """
    return run_agent(request.message)


# =========================================================
# STREAMING CHAT ENDPOINT
# =========================================================

@app.post("/api/chat/stream")
def chat_stream(request: ChatRequest):
    """
    Real-time Server-Sent Events streaming endpoint.
    """

    return StreamingResponse(
        stream_agent(request.message),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )

import json
import re
import time
from typing import Any, Generator

from ollama import Client

from config import OLLAMA_MODEL, OLLAMA_HOST
from rag import rag_system
from tools import (
    get_transaction_status,
    get_customer_details,
    check_refund_eligibility,
    create_support_ticket,
)


# =========================================================
# OLLAMA CONFIGURATION
# =========================================================

ollama_client = Client(
    host=OLLAMA_HOST
)

# Keep generation SHORT.
# Payment support answers normally don't need 450 tokens.
COMMON_OPTIONS = {
    "temperature": 0.1,
    "top_p": 0.8,
    "num_predict": 150,
}

# Qwen3 thinking disabled for lower latency.
THINK_ENABLED = False

# Keep model loaded in RAM.
# -1 = keep loaded indefinitely.
KEEP_ALIVE = -1


# =========================================================
# MODEL RESOLUTION
# =========================================================

_effective_model_cache: str | None = None


def get_effective_model() -> str:
    """
    Resolve the configured Ollama model once.

    The old implementation checked Ollama on every request.
    This implementation performs the check only once.
    """

    global _effective_model_cache

    if _effective_model_cache:
        return _effective_model_cache

    try:
        response = ollama_client.list()

        models = getattr(response, "models", [])

        names = []

        for model in models:
            name = (
                getattr(model, "model", None)
                or getattr(model, "name", "")
            )

            if name:
                names.append(name)

        # Exact configured model
        if OLLAMA_MODEL in names:
            _effective_model_cache = OLLAMA_MODEL
            return _effective_model_cache

        # Partial configured model match
        for name in names:
            if OLLAMA_MODEL in name:
                _effective_model_cache = name
                return _effective_model_cache

        # Fast Qwen fallback
        for name in names:
            if "qwen3:4b" in name:
                _effective_model_cache = "qwen3:4b"
                return _effective_model_cache

        # Last available model
        if names:
            _effective_model_cache = names[0]
            return _effective_model_cache

    except Exception:
        pass

    # Don't cache failed resolution.
    return OLLAMA_MODEL


# =========================================================
# REGEX HELPERS
# =========================================================

TXN_PATTERN = re.compile(r"\bTXN\d+\b", re.IGNORECASE)
CUSTOMER_PATTERN = re.compile(r"\bCUST\d+\b", re.IGNORECASE)
TICKET_PATTERN = re.compile(r"\bTKT-[A-Z0-9]+\b", re.IGNORECASE)


def extract_transaction_id(text: str) -> str | None:
    match = TXN_PATTERN.search(text or "")

    if match:
        return match.group(0).upper()

    return None


def extract_customer_id(text: str) -> str | None:
    match = CUSTOMER_PATTERN.search(text or "")

    if match:
        return match.group(0).upper()

    return None


# =========================================================
# GENERIC HELPERS
# =========================================================

def _first_value(data: dict[str, Any], *keys: str):
    """
    Return first non-empty value.
    """

    for key in keys:
        value = data.get(key)

        if value is not None and value != "":
            return value

    return None


def unique_list(values):
    return list(dict.fromkeys(values))


def sse(payload: dict[str, Any]) -> str:
    """
    Convert dictionary to SSE response.
    """

    return f"data: {json.dumps(payload, ensure_ascii=False)}\n\n"


# =========================================================
# QUERY CLASSIFICATION
# =========================================================

def is_status_query(user_message: str) -> bool:
    """
    Detect transaction status questions.

    These are handled directly from the database.
    """

    text = user_message.lower()

    status_words = (
        "status",
        "state",
        "successful",
        "success",
        "failed",
        "failure",
        "pending",
        "completed",
        "complete",
    )

    return (
        extract_transaction_id(user_message) is not None
        and any(word in text for word in status_words)
    )


def is_refund_query(user_message: str) -> bool:
    text = user_message.lower()

    refund_words = (
        "refund",
        "refunded",
        "reversal",
        "reverse",
        "money back",
        "eligible",
        "eligibility",
    )

    return (
        extract_transaction_id(user_message) is not None
        and any(word in text for word in refund_words)
    )


def is_customer_query(user_message: str) -> bool:
    text = user_message.lower()

    customer_words = (
        "customer",
        "customer details",
        "customer information",
        "account details",
        "user details",
        "profile",
    )

    return (
        extract_customer_id(user_message) is not None
        and any(word in text for word in customer_words)
    )


def is_ticket_query(user_message: str) -> bool:
    text = user_message.lower()

    ticket_words = (
        "ticket",
        "support ticket",
        "raise a ticket",
        "create a ticket",
        "open a ticket",
        "complaint",
        "support request",
        "escalate",
    )

    return any(word in text for word in ticket_words)


# =========================================================
# TRANSACTION RESPONSE
# =========================================================

def format_transaction_status(
    transaction_id: str,
    txn_data: dict[str, Any]
) -> str:
    """
    Fast deterministic transaction status response.
    """

    status = _first_value(
        txn_data,
        "status",
        "transaction_status",
        "state"
    )

    if status is None:
        return (
            f"I couldn't determine the status of "
            f"**{transaction_id}**."
        )

    status_text = str(status).upper()

    response = (
        f"Transaction **{transaction_id}** is **{status_text}**."
    )

    amount = _first_value(
        txn_data,
        "amount",
        "transaction_amount",
        "value"
    )

    merchant = _first_value(
        txn_data,
        "merchant",
        "merchant_name",
        "store",
        "payee"
    )

    method = _first_value(
        txn_data,
        "payment_method",
        "method",
        "mode"
    )

    details = []

    if amount is not None:
        if isinstance(amount, (int, float)):
            details.append(f"Amount: **₹{amount:,}**")
        else:
            details.append(f"Amount: **{amount}**")

    if merchant:
        details.append(f"Merchant: **{merchant}**")

    if method:
        details.append(f"Method: **{method}**")

    if details:
        response += " " + " · ".join(details) + "."

    return response


# =========================================================
# REFUND RESPONSE
# =========================================================

def format_refund_response(
    transaction_id: str,
    refund_data: dict[str, Any]
) -> str:
    """
    Format refund eligibility without LLM.
    """

    eligible = _first_value(
        refund_data,
        "eligible",
        "is_eligible",
        "refund_eligible"
    )

    reason = _first_value(
        refund_data,
        "reason",
        "message",
        "description"
    )

    if isinstance(eligible, str):
        eligible_lower = eligible.lower()

        if eligible_lower in ("true", "yes", "eligible"):
            eligible = True

        elif eligible_lower in ("false", "no", "not eligible"):
            eligible = False

    if eligible is True:
        response = (
            f"Transaction **{transaction_id}** is "
            f"**eligible for a refund**."
        )

        if reason:
            response += f" {reason}"

        return response

    if eligible is False:
        response = (
            f"Transaction **{transaction_id}** is "
            f"**not eligible for a refund**."
        )

        if reason:
            response += f" {reason}"

        return response

    if reason:
        return (
            f"I couldn't confirm the refund eligibility for "
            f"**{transaction_id}**. {reason}"
        )

    return (
        f"I couldn't determine the refund eligibility for "
        f"**{transaction_id}**."
    )


# =========================================================
# CUSTOMER RESPONSE
# =========================================================

def format_customer_details(
    customer_id: str,
    customer_data: dict[str, Any]
) -> str:
    """
    Return useful customer information without LLM.
    """

    if not customer_data.get("found"):
        return (
            f"I couldn't find customer **{customer_id}**."
        )

    name = _first_value(
        customer_data,
        "name",
        "customer_name",
        "full_name"
    )

    email = _first_value(
        customer_data,
        "email",
        "email_address"
    )

    phone = _first_value(
        customer_data,
        "phone",
        "phone_number",
        "mobile"
    )

    details = []

    if name:
        details.append(f"Name: **{name}**")

    if email:
        details.append(f"Email: **{email}**")

    if phone:
        details.append(f"Phone: **{phone}**")

    if not details:
        return (
            f"Customer **{customer_id}** was found, "
            f"but no additional details are available."
        )

    return (
        f"Customer **{customer_id}** — "
        + " · ".join(details)
        + "."
    )


# =========================================================
# TOOL DEFINITIONS
# =========================================================

TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "get_transaction_status",
            "description": (
                "Get complete information about a payment "
                "transaction using its transaction ID."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "transaction_id": {
                        "type": "string",
                        "description": "Transaction ID such as TXN1002"
                    }
                },
                "required": ["transaction_id"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "get_customer_details",
            "description": (
                "Get customer information using customer ID."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "customer_id": {
                        "type": "string",
                        "description": "Customer ID such as CUST001"
                    }
                },
                "required": ["customer_id"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "check_refund_eligibility",
            "description": (
                "Check whether a transaction is eligible "
                "for refund or automatic reversal."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "transaction_id": {
                        "type": "string",
                        "description": "Transaction ID such as TXN1002"
                    }
                },
                "required": ["transaction_id"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "create_support_ticket",
            "description": (
                "Create a customer support ticket for a "
                "transaction-related problem."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "transaction_id": {
                        "type": "string",
                        "description": "Transaction ID"
                    },
                    "issue": {
                        "type": "string",
                        "description": "Description of the issue"
                    },
                    "priority": {
                        "type": "string",
                        "enum": ["NORMAL", "HIGH"],
                        "description": "Priority of the support ticket"
                    }
                },
                "required": [
                    "transaction_id",
                    "issue",
                    "priority"
                ]
            }
        }
    }
]


# =========================================================
# TOOL EXECUTION
# =========================================================

def execute_tool(
    tool_name: str,
    arguments: dict[str, Any]
) -> dict[str, Any]:

    if tool_name == "get_transaction_status":
        return get_transaction_status(
            arguments.get("transaction_id", "")
        )

    if tool_name == "get_customer_details":
        return get_customer_details(
            arguments.get("customer_id", "")
        )

    if tool_name == "check_refund_eligibility":
        return check_refund_eligibility(
            arguments.get("transaction_id", "")
        )

    if tool_name == "create_support_ticket":
        return create_support_ticket(
            arguments.get("transaction_id", ""),
            arguments.get(
                "issue",
                "Customer payment inquiry"
            ),
            arguments.get(
                "priority",
                "NORMAL"
            )
        )

    return {
        "error": f"Unknown tool: {tool_name}"
    }


# =========================================================
# RAG CACHE
# =========================================================

_RAG_CACHE: dict[str, tuple[float, str, list[str]]] = {}

RAG_CACHE_TTL = 300


def build_rag_context(query: str):
    """
    Search only top 1 document and cache repeated questions.
    """

    normalized_query = " ".join(
        query.lower().strip().split()
    )

    now = time.time()

    cached = _RAG_CACHE.get(normalized_query)

    if cached:
        timestamp, context, sources = cached

        if now - timestamp < RAG_CACHE_TTL:
            return context, sources

    results = rag_system.search(
        query,
        top_k=1
    )

    context_parts = []
    sources = []

    for result in results:

        source = result.get("source", "Unknown")
        text = result.get("text", "")

        context_parts.append(
            f"SOURCE: {source}\n{text}"
        )

        if source not in sources:
            sources.append(source)

    context = "\n\n".join(context_parts)

    _RAG_CACHE[normalized_query] = (
        now,
        context,
        sources
    )

    # Prevent unlimited cache growth.
    if len(_RAG_CACHE) > 100:
        oldest_key = min(
            _RAG_CACHE,
            key=lambda key: _RAG_CACHE[key][0]
        )

        del _RAG_CACHE[oldest_key]

    return context, sources


# =========================================================
# SYSTEM PROMPT
# =========================================================

def build_system_prompt(
    rag_context: str,
    database_context: str = ""
) -> str:

    return f"""
You are FinAssist AI, a fast professional payment support assistant.

Your task is to answer customer questions about:
- payments
- failed transactions
- pending transactions
- refunds
- reversals
- transaction problems
- payment policies
- support tickets

STRICT RULES:

1. Give ONLY the final answer.
2. Never reveal reasoning or internal analysis.
3. Never say "the user is asking".
4. Never say "let me check".
5. Never explain your internal process.
6. Answer in 1-3 short sentences.
7. Maximum 50 words.
8. Use Markdown only when useful.
9. Never invent transaction information.
10. Never invent customer information.
11. Never invent refund policies.
12. Use retrieved information as the source of truth.
13. If information is unavailable, say so briefly.
14. Do not repeat the customer's question.
15. Do not output JSON.
16. Do not output tool names.
17. Do not mention RAG, database, model, or internal systems.

PAYMENT POLICY CONTEXT:

{rag_context}

DATABASE CONTEXT:

{database_context}
""".strip()


# =========================================================
# ANSWER CLEANING
# =========================================================

def clean_and_shorten_answer(
    raw_content: str,
    max_words: int = 50
) -> str:

    text = raw_content or ""

    # Remove Qwen thinking tags if they appear.
    text = re.sub(
        r"<think>.*?</think>",
        "",
        text,
        flags=re.DOTALL | re.IGNORECASE
    )

    text = text.replace("<think>", "")
    text = text.replace("</think>", "")

    # Remove common meta prefixes.
    text = re.sub(
        r"^(sure|certainly|okay|of course)[,!:\s.-]+",
        "",
        text,
        flags=re.IGNORECASE
    ).strip()

    if not text:
        return (
            "I couldn't generate a response. "
            "Please try again."
        )

    # Remove obvious reasoning leakage.
    reasoning_markers = (
        "the user is asking",
        "let me check",
        "i should",
        "i need to",
        "wait,",
        "the answer should",
        "let me confirm",
        "the response should be",
        "i can just use",
    )

    paragraphs = [
        p.strip()
        for p in re.split(
            r"\n\s*\n+",
            text
        )
        if p.strip()
    ]

    if (
        len(paragraphs) > 1
        and any(
            marker in text.lower()
            for marker in reasoning_markers
        )
    ):
        text = paragraphs[-1]

    # Limit response length.
    words = text.split()

    if len(words) > max_words:

        sentences = re.split(
            r"(?<=[.!?])\s+",
            text
        )

        kept = []
        count = 0

        for sentence in sentences:

            n = len(sentence.split())

            if kept and count + n > max_words:
                break

            if not kept and n > max_words:
                return (
                    " ".join(words[:max_words])
                    .rstrip(" ,;:")
                    + "."
                )

            kept.append(sentence)
            count += n

        text = " ".join(kept).strip()

    return text


# =========================================================
# FAST PATH
# =========================================================

def try_fast_path(
    user_message: str
):
    """
    Handle deterministic queries without Ollama.

    Returns:
        tuple(answer, tools_used, ticket_id)
    """

    tools_used = []
    ticket_id = None

    txn_id = extract_transaction_id(user_message)
    customer_id = extract_customer_id(user_message)

    # -----------------------------------------------------
    # 1. TRANSACTION STATUS
    # -----------------------------------------------------

    if txn_id and is_status_query(user_message):

        txn_data = get_transaction_status(txn_id)

        tools_used.append(
            "get_transaction_status"
        )

        if not txn_data.get("found"):
            return (
                f"I couldn't find transaction **{txn_id}**.",
                tools_used,
                None
            )

        answer = format_transaction_status(
            txn_id,
            txn_data
        )

        return answer, tools_used, None

    # -----------------------------------------------------
    # 2. REFUND ELIGIBILITY
    # -----------------------------------------------------

    if txn_id and is_refund_query(user_message):

        refund_data = check_refund_eligibility(
            txn_id
        )

        tools_used.append(
            "check_refund_eligibility"
        )

        answer = format_refund_response(
            txn_id,
            refund_data
        )

        return answer, tools_used, None

    # -----------------------------------------------------
    # 3. CUSTOMER DETAILS
    # -----------------------------------------------------

    if customer_id and is_customer_query(user_message):

        customer_data = get_customer_details(
            customer_id
        )

        tools_used.append(
            "get_customer_details"
        )

        answer = format_customer_details(
            customer_id,
            customer_data
        )

        return answer, tools_used, None

    # -----------------------------------------------------
    # 4. DIRECT SUPPORT TICKET
    # -----------------------------------------------------

    if txn_id and is_ticket_query(user_message):

        text = user_message.lower()

        priority = (
            "HIGH"
            if any(
                word in text
                for word in (
                    "urgent",
                    "immediately",
                    "critical",
                    "emergency"
                )
            )
            else "NORMAL"
        )

        ticket_result = create_support_ticket(
            txn_id,
            user_message,
            priority
        )

        tools_used.append(
            "create_support_ticket"
        )

        if ticket_result.get("success"):

            ticket_id = ticket_result.get(
                "ticket_id"
            )

            answer = (
                f"Support ticket **{ticket_id}** "
                f"has been created with **{priority}** priority."
            )

            return answer, tools_used, ticket_id

        return (
            "I couldn't create the support ticket. "
            "Please try again.",
            tools_used,
            None
        )

    return None


# =========================================================
# OLLAMA GENERATION
# =========================================================

def generate_answer(
    user_message: str,
    rag_context: str,
    database_context: str = ""
) -> str:

    model = get_effective_model()

    system_prompt = build_system_prompt(
        rag_context,
        database_context
    )

    messages = [
        {
            "role": "system",
            "content": system_prompt
        },
        {
            "role": "user",
            "content": user_message
        }
    ]

    # IMPORTANT:
    # No tools are passed here for normal RAG questions.
    # This avoids tool-selection overhead.
    response = ollama_client.chat(
        model=model,
        messages=messages,
        think=THINK_ENABLED,
        keep_alive=KEEP_ALIVE,
        options=COMMON_OPTIONS
    )

    message = getattr(
        response,
        "message",
        None
    )

    if not message:
        return (
            "I couldn't generate a response. "
            "Please try again."
        )

    content = getattr(
        message,
        "content",
        ""
    )

    return clean_and_shorten_answer(
        content
    )


# =========================================================
# STREAMING AI AGENT
# =========================================================

def stream_agent(
    user_message: str
) -> Generator[str, None, None]:

    start_time = time.perf_counter()

    tools_used = []
    all_sources = []
    ticket_id = None

    # =====================================================
    # FAST PATH
    # =====================================================

    fast_result = try_fast_path(
        user_message
    )

    if fast_result:

        answer, tools_used, ticket_id = fast_result

        elapsed = round(
            time.perf_counter() - start_time,
            2
        )

        yield sse({
            "type": "status",
            "stage": "completed",
            "message": f"Completed in {elapsed}s"
        })

        yield sse({
            "type": "token",
            "content": answer
        })

        yield sse({
            "type": "done",
            "answer": answer,
            "sources": [],
            "tools_used": unique_list(tools_used),
            "ticket_id": ticket_id,
            "response_time": elapsed
        })

        return

    # =====================================================
    # RAG
    # =====================================================

    yield sse({
        "type": "status",
        "stage": "rag",
        "message": "Searching payment knowledge base..."
    })

    rag_context, rag_sources = build_rag_context(
        user_message
    )

    all_sources.extend(
        rag_sources
    )

    # =====================================================
    # OPTIONAL DATABASE CONTEXT
    # =====================================================

    txn_id = extract_transaction_id(
        user_message
    )

    database_context_parts = []

    if txn_id:

        txn_data = get_transaction_status(
            txn_id
        )

        if txn_data.get("found"):

            tools_used.append(
                "get_transaction_status"
            )

            database_context_parts.append(
                "TRANSACTION RECORD:\n"
                + json.dumps(
                    txn_data,
                    ensure_ascii=False
                )
            )

    database_context = "\n\n".join(
        database_context_parts
    )

    # =====================================================
    # LLM
    # =====================================================

    yield sse({
        "type": "status",
        "stage": "generating",
        "message": "Generating response..."
    })

    try:

        answer = generate_answer(
            user_message,
            rag_context,
            database_context
        )

    except Exception as exc:

        answer = (
            "I encountered a temporary problem "
            "while processing your request. "
            "Please try again."
        )

    elapsed = round(
        time.perf_counter() - start_time,
        2
    )

    # =====================================================
    # FINAL RESPONSE
    # =====================================================

    yield sse({
        "type": "token",
        "content": answer
    })

    yield sse({
        "type": "done",
        "answer": answer,
        "sources": unique_list(all_sources),
        "tools_used": unique_list(tools_used),
        "ticket_id": ticket_id,
        "response_time": elapsed
    })


# =========================================================
# SYNCHRONOUS AGENT
# =========================================================

def run_agent(
    user_message: str
) -> dict[str, Any]:

    start_time = time.perf_counter()

    tools_used = []
    all_sources = []
    ticket_id = None

    # =====================================================
    # FAST PATH
    # =====================================================

    fast_result = try_fast_path(
        user_message
    )

    if fast_result:

        answer, tools_used, ticket_id = fast_result

        elapsed = round(
            time.perf_counter() - start_time,
            2
        )

        return {
            "answer": answer,
            "sources": [],
            "tools_used": unique_list(tools_used),
            "ticket_id": ticket_id,
            "response_time": elapsed
        }

    # =====================================================
    # RAG
    # =====================================================

    rag_context, rag_sources = build_rag_context(
        user_message
    )

    all_sources.extend(
        rag_sources
    )

    # =====================================================
    # DATABASE CONTEXT
    # =====================================================

    txn_id = extract_transaction_id(
        user_message
    )

    database_context_parts = []

    if txn_id:

        txn_data = get_transaction_status(
            txn_id
        )

        if txn_data.get("found"):

            tools_used.append(
                "get_transaction_status"
            )

            database_context_parts.append(
                "TRANSACTION RECORD:\n"
                + json.dumps(
                    txn_data,
                    ensure_ascii=False
                )
            )

    database_context = "\n\n".join(
        database_context_parts
    )

    # =====================================================
    # LLM
    # =====================================================

    try:

        answer = generate_answer(
            user_message,
            rag_context,
            database_context
        )

    except Exception:

        answer = (
            "I encountered a temporary problem "
            "while processing your request. "
            "Please try again."
        )

    elapsed = round(
        time.perf_counter() - start_time,
        2
    )

    return {
        "answer": answer,
        "sources": unique_list(all_sources),
        "tools_used": unique_list(tools_used),
        "ticket_id": ticket_id,
        "response_time": elapsed
    }


# =========================================================
# PAYMENT POLICY SEARCH
# =========================================================

def search_payment_policy(
    query: str
):
    """
    Search payment policy documents.

    top_k=3 instead of 4 to reduce processing.
    """

    results = rag_system.search(
        query,
        top_k=3
    )

    formatted_results = []

    for result in results:

        formatted_results.append({
            "source": result.get(
                "source",
                "Unknown"
            ),
            "content": result.get(
                "text",
                ""
            ),
            "similarity": result.get(
                "score",
                0
            )
        })

    return formatted_results


from pathlib import Path
import pickle
import time
from functools import lru_cache

import numpy as np
from sentence_transformers import SentenceTransformer
from langchain_text_splitters import RecursiveCharacterTextSplitter


# =========================================================
# PATHS
# =========================================================

BASE_DIR = Path(__file__).parent

KNOWLEDGE_DIR = BASE_DIR / "knowledge_base"
VECTOR_DIR = BASE_DIR / "vector_store"

VECTOR_DIR.mkdir(exist_ok=True)


EMBEDDINGS_PATH = VECTOR_DIR / "embeddings.npy"
DOCS_PATH = VECTOR_DIR / "documents.pkl"


# =========================================================
# RAG CONFIGURATION
# =========================================================

MODEL_NAME = "all-MiniLM-L6-v2"

DEFAULT_TOP_K = 1

# Ignore extremely weak semantic matches.
SIMILARITY_THRESHOLD = 0.30

# Keep RAG query results in memory for 5 minutes.
CACHE_TTL = 300

# Maximum cached queries.
MAX_CACHE_SIZE = 100


# =========================================================
# RAG SYSTEM
# =========================================================

class RAGSystem:

    def __init__(self):

        print("Loading embedding model...")

        start = time.perf_counter()

        self.embedding_model = SentenceTransformer(
            MODEL_NAME,
            device="cpu"
        )

        # Inference only.
        self.embedding_model.eval()

        self.documents = []

        self.embeddings = None

        # Query result cache:
        #
        # normalized_query:
        # (
        #     timestamp,
        #     results
        # )
        self._query_cache = {}

        # Query embedding cache.
        self._embedding_cache = {}

        model_time = round(
            time.perf_counter() - start,
            2
        )

        print(
            f"Embedding model loaded in {model_time}s"
        )

        # =====================================================
        # LOAD EXISTING VECTOR STORE
        # =====================================================

        if (
            EMBEDDINGS_PATH.exists()
            and DOCS_PATH.exists()
        ):

            print(
                "Loading existing vector store..."
            )

            self.embeddings = np.load(
                str(EMBEDDINGS_PATH),
                allow_pickle=False
            )

            with open(
                DOCS_PATH,
                "rb"
            ) as file:

                self.documents = pickle.load(
                    file
                )

            print(
                f"Loaded {len(self.documents)} chunks."
            )

        else:

            print(
                "Creating vector store..."
            )

            self.build_index()

    # =========================================================
    # BUILD INDEX
    # =========================================================

    def build_index(self):

        splitter = RecursiveCharacterTextSplitter(
            chunk_size=700,
            chunk_overlap=80
        )

        chunks = []

        if not KNOWLEDGE_DIR.exists():

            raise RuntimeError(
                f"Knowledge base directory not found: "
                f"{KNOWLEDGE_DIR}"
            )

        for file_path in KNOWLEDGE_DIR.glob(
            "*.txt"
        ):

            try:

                text = file_path.read_text(
                    encoding="utf-8"
                )

            except Exception as exc:

                print(
                    f"Could not read {file_path.name}: "
                    f"{exc}"
                )

                continue

            if not text.strip():
                continue

            file_chunks = splitter.split_text(
                text
            )

            for chunk in file_chunks:

                chunks.append({
                    "text": chunk,
                    "source": file_path.name
                })

        if not chunks:

            raise RuntimeError(
                "No knowledge base documents found."
            )

        texts = [
            chunk["text"]
            for chunk in chunks
        ]

        print(
            f"Generating embeddings for "
            f"{len(texts)} chunks..."
        )

        start = time.perf_counter()

        embeddings = self.embedding_model.encode(
            texts,
            batch_size=32,
            show_progress_bar=False,
            normalize_embeddings=True,
            convert_to_numpy=True
        )

        embeddings = np.asarray(
            embeddings,
            dtype=np.float32
        )

        # Make sure matrix is contiguous.
        embeddings = np.ascontiguousarray(
            embeddings
        )

        self.embeddings = embeddings
        self.documents = chunks

        np.save(
            str(EMBEDDINGS_PATH),
            self.embeddings
        )

        with open(
            DOCS_PATH,
            "wb"
        ) as file:

            pickle.dump(
                self.documents,
                file,
                protocol=pickle.HIGHEST_PROTOCOL
            )

        elapsed = round(
            time.perf_counter() - start,
            2
        )

        print(
            f"Indexed {len(chunks)} chunks "
            f"in {elapsed}s."
        )

    # =========================================================
    # NORMALIZE QUERY
    # =========================================================

    @staticmethod
    def _normalize_query(
        query: str
    ) -> str:

        return " ".join(
            query.lower().strip().split()
        )

    # =========================================================
    # QUERY EMBEDDING
    # =========================================================

    def _get_query_embedding(
        self,
        query: str
    ):

        normalized = self._normalize_query(
            query
        )

        cached = self._embedding_cache.get(
            normalized
        )

        if cached is not None:

            return cached

        embedding = self.embedding_model.encode(
            query,
            normalize_embeddings=True,
            convert_to_numpy=True,
            show_progress_bar=False
        )

        embedding = np.asarray(
            embedding,
            dtype=np.float32
        )

        embedding = np.ascontiguousarray(
            embedding
        )

        # Keep cache bounded.
        if len(self._embedding_cache) >= MAX_CACHE_SIZE:

            oldest_key = next(
                iter(self._embedding_cache)
            )

            del self._embedding_cache[
                oldest_key
            ]

        self._embedding_cache[
            normalized
        ] = embedding

        return embedding

    # =========================================================
    # SEARCH
    # =========================================================

    def search(
        self,
        query: str,
        top_k: int = DEFAULT_TOP_K
    ):

        if (
            not query
            or self.embeddings is None
            or len(self.documents) == 0
        ):

            return []

        normalized_query = self._normalize_query(
            query
        )

        now = time.time()

        # =====================================================
        # CACHE
        # =====================================================

        cached = self._query_cache.get(
            normalized_query
        )

        if cached:

            timestamp, cached_results = cached

            if now - timestamp < CACHE_TTL:

                # Return copies so callers cannot mutate
                # cached data.
                return [
                    item.copy()
                    for item in cached_results[:top_k]
                ]

            del self._query_cache[
                normalized_query
            ]

        # =====================================================
        # QUERY EMBEDDING
        # =====================================================

        query_embedding = self._get_query_embedding(
            query
        )

        # =====================================================
        # COSINE SIMILARITY
        # =====================================================

        scores = self.embeddings @ query_embedding

        k = min(
            max(1, top_k),
            len(scores)
        )

        # For very small knowledge bases, sorting directly
        # is fast enough and simpler.
        if len(scores) <= 100:

            top_indices = np.argsort(
                -scores
            )[:k]

        else:

            top_indices = np.argpartition(
                -scores,
                k - 1
            )[:k]

            top_indices = top_indices[
                np.argsort(
                    -scores[top_indices]
                )
            ]

        # =====================================================
        # BUILD RESULTS
        # =====================================================

        results = []

        for index in top_indices:

            score = float(
                scores[index]
            )

            # Don't send irrelevant context to LLM.
            if score < SIMILARITY_THRESHOLD:
                continue

            document = self.documents[
                int(index)
            ].copy()

            document["score"] = score

            results.append(
                document
            )

        # =====================================================
        # CACHE RESULTS
        # =====================================================

        if len(self._query_cache) >= MAX_CACHE_SIZE:

            oldest_key = next(
                iter(self._query_cache)
            )

            del self._query_cache[
                oldest_key
            ]

        self._query_cache[
            normalized_query
        ] = (
            now,
            results
        )

        return [
            item.copy()
            for item in results
        ]

    # =========================================================
    # CLEAR CACHE
    # =========================================================

    def clear_cache(self):

        self._query_cache.clear()

        self._embedding_cache.clear()

        print(
            "RAG cache cleared."
        )

    # =========================================================
    # REBUILD INDEX
    # =========================================================

    def rebuild(self):

        print(
            "Rebuilding RAG vector store..."
        )

        self.build_index()

        self.clear_cache()


# =========================================================
# GLOBAL RAG INSTANCE
# =========================================================

rag_system = RAGSystem()
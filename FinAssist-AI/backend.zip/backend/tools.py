
from datetime import datetime
import uuid

from database import get_connection


# =========================================================
# TRANSACTION STATUS
# =========================================================

def get_transaction_status(
    transaction_id: str
):

    transaction_id = (
        transaction_id or ""
    ).strip().upper()

    if not transaction_id:

        return {
            "found": False,
            "message": "Transaction ID is required."
        }

    connection = get_connection()

    try:

        cursor = connection.cursor()

        cursor.execute(
            """
            SELECT
                transaction_id,
                customer_id,
                amount,
                merchant,
                status,
                payment_method,
                transaction_date
            FROM transactions
            WHERE transaction_id = ?
            LIMIT 1
            """,
            (transaction_id,)
        )

        row = cursor.fetchone()

        if not row:

            return {
                "found": False,
                "message": "Transaction not found."
            }

        return {
            "found": True,
            "transaction_id": row["transaction_id"],
            "customer_id": row["customer_id"],
            "amount": row["amount"],
            "merchant": row["merchant"],
            "status": row["status"],
            "payment_method": row["payment_method"],
            "transaction_date": row["transaction_date"]
        }

    finally:

        connection.close()


# =========================================================
# CUSTOMER DETAILS
# =========================================================

def get_customer_details(
    customer_id: str
):

    customer_id = (
        customer_id or ""
    ).strip().upper()

    if not customer_id:

        return {
            "found": False,
            "message": "Customer ID is required."
        }

    connection = get_connection()

    try:

        cursor = connection.cursor()

        cursor.execute(
            """
            SELECT
                customer_id,
                name,
                email,
                account_type
            FROM customers
            WHERE customer_id = ?
            LIMIT 1
            """,
            (customer_id,)
        )

        row = cursor.fetchone()

        if not row:

            return {
                "found": False,
                "message": "Customer not found."
            }

        return {
            "found": True,
            "customer_id": row["customer_id"],
            "name": row["name"],
            "email": row["email"],
            "account_type": row["account_type"]
        }

    finally:

        connection.close()


# =========================================================
# REFUND ELIGIBILITY
# =========================================================

def check_refund_eligibility(
    transaction_id: str
):

    transaction_id = (
        transaction_id or ""
    ).strip().upper()

    transaction = get_transaction_status(
        transaction_id
    )

    if not transaction["found"]:

        return {
            "eligible": False,
            "reason": "Transaction not found."
        }

    status = str(
        transaction.get("status", "")
    ).upper()

    # -----------------------------------------------------
    # PENDING
    # -----------------------------------------------------

    if status == "PENDING":

        return {
            "eligible": False,
            "reason": (
                "Transaction is still pending. "
                "It should reach a final state before "
                "refund processing."
            )
        }

    # -----------------------------------------------------
    # FAILED
    # -----------------------------------------------------

    if status == "FAILED":

        return {
            "eligible": True,
            "reason": (
                "Failed transactions can be eligible "
                "for automatic reversal."
            )
        }

    # -----------------------------------------------------
    # SUCCESS
    # -----------------------------------------------------

    if status == "SUCCESS":

        return {
            "eligible": False,
            "reason": (
                "Successful transactions are not eligible "
                "for failed-payment reversal."
            )
        }

    # -----------------------------------------------------
    # UNKNOWN STATUS
    # -----------------------------------------------------

    return {
        "eligible": False,
        "reason": (
            f"Refund eligibility cannot be determined "
            f"for transaction status {status or 'UNKNOWN'}."
        )
    }


# =========================================================
# CREATE SUPPORT TICKET
# =========================================================

def create_support_ticket(
    transaction_id: str,
    issue: str,
    priority: str = "NORMAL"
):

    transaction_id = (
        transaction_id or ""
    ).strip().upper()

    issue = (
        issue or "Customer payment inquiry"
    ).strip()

    priority = (
        priority or "NORMAL"
    ).strip().upper()

    if priority not in (
        "NORMAL",
        "HIGH"
    ):

        priority = "NORMAL"

    # -----------------------------------------------------
    # Validate transaction first.
    # -----------------------------------------------------

    transaction = get_transaction_status(
        transaction_id
    )

    if not transaction["found"]:

        return {
            "success": False,
            "message": "Transaction not found."
        }

    # -----------------------------------------------------
    # Generate ticket.
    # -----------------------------------------------------

    ticket_id = (
        "TKT-"
        + uuid.uuid4().hex[:8].upper()
    )

    created_at = datetime.now().isoformat(
        timespec="seconds"
    )

    connection = get_connection()

    try:

        cursor = connection.cursor()

        cursor.execute(
            """
            INSERT INTO support_tickets
            (
                ticket_id,
                transaction_id,
                issue,
                priority,
                status,
                created_at
            )
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                ticket_id,
                transaction_id,
                issue,
                priority,
                "OPEN",
                created_at
            )
        )

        connection.commit()

        return {
            "success": True,
            "ticket_id": ticket_id,
            "transaction_id": transaction_id,
            "priority": priority,
            "status": "OPEN",
            "created_at": created_at
        }

    except Exception:

        connection.rollback()

        return {
            "success": False,
            "message": (
                "Unable to create support ticket."
            )
        }

    finally:

        connection.close()

from pydantic import BaseModel
from typing import List, Optional


class ChatRequest(BaseModel):
    message: str


class ChatResponse(BaseModel):
    answer: str
    tools_used: List[str] = []
    sources: List[str] = []
    ticket_id: Optional[str] = None
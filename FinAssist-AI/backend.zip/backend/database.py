import sqlite3
from pathlib import Path


import sqlite3
from pathlib import Path


# =========================================================
# DATABASE CONFIGURATION
# =========================================================

BASE_DIR = Path(__file__).parent

DATABASE_PATH = BASE_DIR / "finassist.db"


# =========================================================
# DATABASE CONNECTION
# =========================================================

def get_connection():

    connection = sqlite3.connect(
        DATABASE_PATH,
        timeout=5
    )

    connection.row_factory = sqlite3.Row

    return connection


# =========================================================
# INITIALIZE AUTH TABLE
# =========================================================

def initialize_auth_database():

    connection = get_connection()

    cursor = connection.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
    """)

    connection.commit()
    connection.close()

DB_PATH = Path(__file__).parent / "finassist.db"


def get_connection():
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    return connection


def initialize_database():
    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS customers (
            customer_id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            email TEXT NOT NULL,
            account_type TEXT NOT NULL
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS transactions (
            transaction_id TEXT PRIMARY KEY,
            customer_id TEXT NOT NULL,
            amount REAL NOT NULL,
            merchant TEXT NOT NULL,
            status TEXT NOT NULL,
            payment_method TEXT NOT NULL,
            transaction_date TEXT NOT NULL,
            FOREIGN KEY(customer_id) REFERENCES customers(customer_id)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS support_tickets (
            ticket_id TEXT PRIMARY KEY,
            transaction_id TEXT NOT NULL,
            issue TEXT NOT NULL,
            priority TEXT NOT NULL,
            status TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
    """)

    # Sample customers
    customers = [
        ("CUST001", "Rahul Sharma", "rahul@example.com", "Savings"),
        ("CUST002", "Priya Patil", "priya@example.com", "Current"),
        ("CUST003", "Amit Joshi", "amit@example.com", "Savings"),
    ]

    cursor.executemany("""
        INSERT OR IGNORE INTO customers
        VALUES (?, ?, ?, ?)
    """, customers)

    # Sample transactions
    transactions = [
        (
            "TXN1001",
            "CUST001",
            5000,
            "ABC Store",
            "SUCCESS",
            "UPI",
            "2026-09-20"
        ),
        (
            "TXN1002",
            "CUST002",
            2500,
            "XYZ Store",
            "FAILED",
            "UPI",
            "2026-09-15"
        ),
        (
            "TXN1003",
            "CUST003",
            1200,
            "Online Mart",
            "PENDING",
            "CARD",
            "2026-09-21"
        ),
        (
            "TXN1004",
            "CUST001",
            7500,
            "Travel Portal",
            "FAILED",
            "CARD",
            "2026-09-10"
        ),
    ]

    cursor.executemany("""
        INSERT OR IGNORE INTO transactions
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, transactions)

    connection.commit()
    connection.close()
    
    
    
    